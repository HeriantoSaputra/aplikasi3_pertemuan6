<?php session_start(); ?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.1.0.js"></script>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<a href="create.php" class="btn btn-sm btn-success">Tambah Data</a>
<div style="float:right;">User : <?php echo $_SESSION['nama'];?></div>
<br></br>
<table id="tabel-data" class="table table-striped table-bordered" width="100%" cellspacing="0">
	<thead>
	<tr>			
		<th>No</th>
		<th>NIM</th>
		<th>Nama Mahasiswa</th>
		<th>Gender</th>
		<th>Nilai</th>
		<th>Tanggal Input</th>
		<th>Delete</th>
	</tr>
	<tbody>
	<?php
	
	$no = 0;
	include 'koneksi.php';
	$query  = mysqli_query($mysqli,"SELECT * FROM tb_mahasiswa");
	while($result = mysqli_fetch_array($query)){
		$no++;
?>		
	<tr>
		<td><?php echo $no;?></td>
		<td><?php echo $result['nim'];?></td>
		<td><?php echo $result['nama'];?></td>
		<td><?php echo $result['gender'];?></td>
		<td><?php echo $result['nilai'];?></td>
		<td><?php echo $result['waktu_input'];?></td>
		<td>
		<a href="delete.php?id=<?php echo $result['id'];?>" class="btn btn-sm btn-danger text-white">Delete</a>
		<a href="form-update.php?id=<?php echo $result['id'];?>" class='btn btn-sm btn-success text-white'>Update</a>
		</td>
	</tr>	
	
<?php }
?>

	
	</tbody>
</table>
<a href="index.php" class="btn btn-sm btn-danger">Logout</a>

<script>
  $(document).ready(function(){
    $('#tabel-data').DataTable();
});
  </script>