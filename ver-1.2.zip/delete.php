<?php
include 'koneksi.php';

$id = $_GET['id'];
$query  = mysqli_query($mysqli,"DELETE FROM tb_mahasiswa WHERE id = '$id'");

header('Location:data-mahasiswa.php');
exit;
?>