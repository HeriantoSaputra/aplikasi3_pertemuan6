<?php
session_start();
include 'koneksi.php';

$username = $_POST['username'];
$password = $_POST['password'];

$query  = mysqli_query($mysqli,"SELECT count(id)cek FROM tb_mahasiswa WHERE nama='$username' AND nim='$password'");
$result = mysqli_fetch_array($query);

if($result['cek']>0){
    $_SESSION['nama'] = $username;
    header('Location:data-mahasiswa.php');
}
else{
    header('Location:index.php');
}
// echo $result['cek'];
// echo $username;
// echo $password;
?>