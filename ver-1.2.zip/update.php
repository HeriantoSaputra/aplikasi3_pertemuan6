<?php
include 'koneksi.php';

$id 	= $_GET['id'];
$nama   = $_GET['nama'];
$nim    = $_GET['nim'];
$gender = $_GET['gender'];
$nilai  = $_GET['nilai'];
$query  = mysqli_query($mysqli,"UPDATE tb_mahasiswa SET 
nama = '$nama', nim = '$nim', gender = '$gender', nilai = '$nilai' WHERE id = '$id';");

header('Location:data-mahasiswa.php');
exit;
?>