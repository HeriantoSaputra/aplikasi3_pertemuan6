<style>
center{font-family:Arial;}    
button{width:300px; height:40px; background:dodgerblue;}
input{width:300px; height:40px;}
</style>
<form method="post" action="authentikasi.php">    
<center>
<img src="https://i.ibb.co/gm2D4wL/profile2.png" width="150px;"></a>
<h1>Form Login</h1>
<table>
<tr>
    <td><input name="username" placeholder="Username" required></td>
</tr>
<tr>
    <td><input name="password" placeholder="Password" required></td>
</tr>
<tr>
    <td><button>Login</button></td>
</tr>
</center>
</form>